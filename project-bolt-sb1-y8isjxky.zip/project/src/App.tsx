import { useState } from 'react';
import { Loader2 } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { ADMIN_EMAIL } from '@/lib/constants';
import { useSession } from '@/hooks/useSession';
import { useAppSettings } from '@/hooks/useAppSettings';
import LoginScreen from '@/components/LoginScreen';
import CustomerApp from '@/components/CustomerApp';
import AdminDashboard from '@/components/admin/AdminDashboard';

type View = 'login' | 'customer' | 'admin';

function App() {
  const { session, loading } = useSession();
  const { settings } = useAppSettings();
  const [customerPhone, setCustomerPhone] = useState('');
  const [manualView, setManualView] = useState<View | null>(null);

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-primary-50 via-white to-primary-100 flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-primary-600" />
      </div>
    );
  }

  const isAdminSession = session?.user?.email === ADMIN_EMAIL;

  const view: View = manualView ?? (isAdminSession ? 'admin' : 'login');

  async function handleSignOut() {
    await supabase.auth.signOut();
    setManualView('login');
    setCustomerPhone('');
  }

  function handleEnterAsCustomer() {
    setManualView('customer');
  }

  if (view === 'admin' && isAdminSession) {
    return <AdminDashboard onSignOut={handleSignOut} />;
  }

  if (view === 'customer') {
    return (
      <CustomerApp
        customerPhone={customerPhone || '09xxxxxxxx'}
        onExit={handleSignOut}
      />
    );
  }

  return (
    <LoginScreen
      settings={settings}
      onEnterAsCustomer={handleEnterAsCustomer}
    />
  );
}

export default App;
