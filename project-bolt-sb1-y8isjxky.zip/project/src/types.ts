export interface Meal {
  id: string;
  name: string;
  price: number;
  image_url: string | null;
  created_at: string;
}

export type OrderStatus =
  | 'pending'
  | 'accepted'
  | 'preparing'
  | 'on_the_way'
  | 'completed'
  | 'cancelled';

export interface Order {
  id: string;
  meal_id: string | null;
  meal_name: string;
  meal_price: number;
  quantity: number;
  phone: string;
  latitude: number | null;
  longitude: number | null;
  status: OrderStatus;
  created_at: string;
}

export interface AppSettings {
  id: number;
  app_name: string;
  logo_url: string | null;
}

export interface AdminProfile {
  id: number;
  username: string;
  phone: string;
}

export interface ChatRoom {
  id: string;
  customer_phone: string;
  customer_name: string | null;
  last_message_at: string;
  created_at: string;
}

export interface ChatMessage {
  id: string;
  room_id: string;
  sender: 'customer' | 'admin';
  body: string | null;
  image_url: string | null;
  created_at: string;
}
