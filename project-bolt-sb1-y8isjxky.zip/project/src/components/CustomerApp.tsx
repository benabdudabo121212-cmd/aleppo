import { useState } from 'react';
import { Loader2, MessageCircle, ShoppingBag, UtensilsCrossed } from 'lucide-react';
import { useMeals } from '@/hooks/useMeals';
import { useAppSettings } from '@/hooks/useAppSettings';
import OrderModal from './OrderModal';
import CustomerChat from './CustomerChat';
import type { Meal } from '@/types';

interface CustomerAppProps {
  customerPhone: string;
  onExit: () => void;
}

export default function CustomerApp({ customerPhone, onExit }: CustomerAppProps) {
  const { meals, loading } = useMeals();
  const { settings } = useAppSettings();
  const [selectedMeal, setSelectedMeal] = useState<Meal | null>(null);
  const [showChat, setShowChat] = useState(false);

  if (showChat) {
    return <CustomerChat phone={customerPhone} onBack={() => setShowChat(false)} />;
  }

  return (
    <div className="min-h-screen bg-neutral-50 pb-24">
      <header className="bg-primary-600 text-white sticky top-0 z-30 shadow-card">
        <div className="max-w-5xl mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-11 h-11 rounded-2xl bg-white/20 flex items-center justify-center overflow-hidden">
              {settings.logo_url ? (
                <img src={settings.logo_url} alt={settings.app_name} className="w-full h-full object-cover" />
              ) : (
                <UtensilsCrossed className="w-6 h-6" />
              )}
            </div>
            <div>
              <h1 className="font-bold text-lg leading-tight">{settings.app_name}</h1>
              <p className="text-xs text-primary-100">وجبتك المفضلة في الطريق</p>
            </div>
          </div>
          <button
            onClick={onExit}
            className="text-sm bg-white/15 hover:bg-white/25 rounded-2xl px-3 py-2 transition"
          >
            خروج
          </button>
        </div>
      </header>

      <div className="max-w-5xl mx-auto px-4 py-6">
        <h2 className="text-xl font-bold text-secondary-900 mb-4">قائمة الطعام</h2>

        {loading ? (
          <div className="flex justify-center py-20">
            <Loader2 className="w-8 h-8 animate-spin text-primary-600" />
          </div>
        ) : meals.length === 0 ? (
          <div className="text-center py-20 text-neutral-400">
            <ShoppingBag className="w-12 h-12 mx-auto mb-3 opacity-50" />
            <p>لا توجد وجبات متاحة حالياً</p>
          </div>
        ) : (
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
            {meals.map((meal) => (
              <button
                key={meal.id}
                onClick={() => setSelectedMeal(meal)}
                className="group bg-white rounded-4xl overflow-hidden shadow-card hover:shadow-card-hover transition-all duration-300 text-right"
              >
                <div className="aspect-square overflow-hidden bg-neutral-100">
                  {meal.image_url ? (
                    <img
                      src={meal.image_url}
                      alt={meal.name}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                    />
                  ) : (
                    <div className="w-full h-full flex items-center justify-center">
                      <UtensilsCrossed className="w-10 h-10 text-neutral-300" />
                    </div>
                  )}
                </div>
                <div className="p-3">
                  <h3 className="font-bold text-secondary-900 text-sm leading-snug line-clamp-2 mb-1">{meal.name}</h3>
                  <p className="text-primary-600 font-bold text-sm">
                    {Number(meal.price).toLocaleString('ar')} ل.س
                  </p>
                </div>
              </button>
            ))}
          </div>
        )}
      </div>

      {selectedMeal && (
        <OrderModal meal={selectedMeal} onClose={() => setSelectedMeal(null)} onOpenChat={() => setShowChat(true)} />
      )}

      <button
        onClick={() => setShowChat(true)}
        className="fixed bottom-5 left-5 z-40 w-14 h-14 rounded-full bg-primary-600 hover:bg-primary-700 text-white shadow-card-hover flex items-center justify-center transition"
        aria-label="المحادثة"
      >
        <MessageCircle className="w-6 h-6" />
      </button>
    </div>
  );
}
