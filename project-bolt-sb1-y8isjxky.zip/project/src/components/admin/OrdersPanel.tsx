import { Loader2, MapPin, Phone, ShoppingBag } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { useOrders } from '@/hooks/useOrders';
import type { Order, OrderStatus } from '@/types';

const STATUS_LABELS: Record<OrderStatus, string> = {
  pending: 'قيد الانتظار',
  accepted: 'تم القبول',
  preparing: 'قيد التحضير',
  on_the_way: 'في الطريق',
  completed: 'مكتمل',
  cancelled: 'ملغي',
};

const STATUS_COLORS: Record<OrderStatus, string> = {
  pending: 'bg-warning-100 text-warning-700',
  accepted: 'bg-primary-100 text-primary-700',
  preparing: 'bg-accent-100 text-accent-700',
  on_the_way: 'bg-blue-100 text-blue-700',
  completed: 'bg-success-100 text-success-700',
  cancelled: 'bg-error-100 text-error-700',
};

const NEXT_STATUSES: Partial<Record<OrderStatus, OrderStatus>> = {
  pending: 'accepted',
  accepted: 'preparing',
  preparing: 'on_the_way',
  on_the_way: 'completed',
};

export default function OrdersPanel() {
  const { orders, loading } = useOrders();

  async function updateStatus(id: string, status: OrderStatus) {
    await supabase.from('orders').update({ status }).eq('id', id);
  }

  if (loading) {
    return (
      <div className="flex justify-center py-12">
        <Loader2 className="w-6 h-6 animate-spin text-primary-600" />
      </div>
    );
  }

  if (orders.length === 0) {
    return (
      <div className="text-center py-12 text-neutral-400">
        <ShoppingBag className="w-10 h-10 mx-auto mb-2 opacity-50" />
        <p>لا توجد طلبات بعد</p>
      </div>
    );
  }

  return (
    <div className="space-y-3">
      <h2 className="text-xl font-bold text-secondary-900">الطلبات الواردة</h2>
      {orders.map((order) => (
        <OrderCard key={order.id} order={order} onUpdateStatus={updateStatus} />
      ))}
    </div>
  );
}

function OrderCard({
  order,
  onUpdateStatus,
}: {
  order: Order;
  onUpdateStatus: (id: string, status: OrderStatus) => void;
}) {
  const nextStatus = NEXT_STATUSES[order.status];

  return (
    <div className="bg-white rounded-3xl p-4 shadow-card animate-fade-in">
      <div className="flex items-start justify-between gap-3 mb-3">
        <div className="flex-1">
          <h3 className="font-bold text-secondary-900">{order.meal_name}</h3>
          <p className="text-sm text-neutral-500 mt-0.5">
            {order.quantity} × {Number(order.meal_price).toLocaleString('ar')} ل.س ={' '}
            <span className="font-bold text-primary-600">
              {(order.quantity * order.meal_price).toLocaleString('ar')} ل.س
            </span>
          </p>
        </div>
        <span className={`text-xs font-bold px-3 py-1 rounded-full ${STATUS_COLORS[order.status]}`}>
          {STATUS_LABELS[order.status]}
        </span>
      </div>

      <div className="flex flex-wrap gap-3 text-sm text-neutral-600 mb-3">
        <span className="flex items-center gap-1">
          <Phone className="w-4 h-4 text-primary-500" />
          {order.phone}
        </span>
        {order.latitude != null && order.longitude != null && (
          <a
            href={`https://www.google.com/maps?q=${order.latitude},${order.longitude}`}
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center gap-1 text-primary-600 hover:underline"
          >
            <MapPin className="w-4 h-4" />
            عرض الموقع
          </a>
        )}
        <span className="text-neutral-400">
          {new Date(order.created_at).toLocaleString('ar', { dateStyle: 'short', timeStyle: 'short' })}
        </span>
      </div>

      {order.status !== 'completed' && order.status !== 'cancelled' && (
        <div className="flex gap-2">
          {nextStatus && (
            <button
              onClick={() => onUpdateStatus(order.id, nextStatus)}
              className="flex-1 bg-primary-600 hover:bg-primary-700 text-white font-bold rounded-xl py-2 text-sm transition"
            >
              {STATUS_LABELS[nextStatus]}
            </button>
          )}
          <button
            onClick={() => onUpdateStatus(order.id, 'cancelled')}
            className="bg-error-50 hover:bg-error-100 text-error-600 font-bold rounded-xl px-4 py-2 text-sm transition"
          >
            إلغاء
          </button>
        </div>
      )}
    </div>
  );
}
