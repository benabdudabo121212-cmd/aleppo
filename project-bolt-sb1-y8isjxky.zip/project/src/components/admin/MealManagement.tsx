import { useState } from 'react';
import { Loader2, Pencil, Plus, Trash2, UtensilsCrossed, X } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { useMeals } from '@/hooks/useMeals';
import type { Meal } from '@/types';

export default function MealManagement() {
  const { meals, loading } = useMeals();
  const [showForm, setShowForm] = useState(false);
  const [editingMeal, setEditingMeal] = useState<Meal | null>(null);

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h2 className="text-xl font-bold text-secondary-900">إدارة الوجبات</h2>
        <button
          onClick={() => {
            setEditingMeal(null);
            setShowForm(true);
          }}
          className="bg-primary-600 hover:bg-primary-700 text-white font-bold rounded-2xl px-4 py-2.5 transition flex items-center gap-2 text-sm"
        >
          <Plus className="w-5 h-5" />
          إضافة وجبة
        </button>
      </div>

      {loading ? (
        <div className="flex justify-center py-12">
          <Loader2 className="w-6 h-6 animate-spin text-primary-600" />
        </div>
      ) : meals.length === 0 ? (
        <div className="text-center py-12 text-neutral-400">
          <UtensilsCrossed className="w-10 h-10 mx-auto mb-2 opacity-50" />
          <p>لا توجد وجبات بعد</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {meals.map((meal) => (
            <div key={meal.id} className="bg-white rounded-3xl overflow-hidden shadow-card flex">
              <div className="w-24 h-24 flex-shrink-0 bg-neutral-100">
                {meal.image_url ? (
                  <img src={meal.image_url} alt={meal.name} className="w-full h-full object-cover" />
                ) : (
                  <div className="w-full h-full flex items-center justify-center">
                    <UtensilsCrossed className="w-6 h-6 text-neutral-300" />
                  </div>
                )}
              </div>
              <div className="flex-1 p-3 flex flex-col justify-between">
                <div>
                  <h3 className="font-bold text-secondary-900 text-sm leading-snug">{meal.name}</h3>
                  <p className="text-primary-600 font-bold text-sm mt-1">
                    {Number(meal.price).toLocaleString('ar')} ل.س
                  </p>
                </div>
                <div className="flex gap-2 mt-2">
                  <button
                    onClick={() => {
                      setEditingMeal(meal);
                      setShowForm(true);
                    }}
                    className="flex-1 bg-neutral-100 hover:bg-primary-100 text-neutral-600 hover:text-primary-600 rounded-xl py-1.5 transition flex items-center justify-center gap-1 text-xs font-medium"
                  >
                    <Pencil className="w-3.5 h-3.5" />
                    تعديل
                  </button>
                  <button
                    onClick={async () => {
                      if (confirm(`حذف "${meal.name}"؟`)) {
                        await supabase.from('meals').delete().eq('id', meal.id);
                      }
                    }}
                    className="flex-1 bg-neutral-100 hover:bg-error-100 text-neutral-600 hover:text-error-600 rounded-xl py-1.5 transition flex items-center justify-center gap-1 text-xs font-medium"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                    حذف
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {showForm && (
        <MealForm
          meal={editingMeal}
          onClose={() => {
            setShowForm(false);
            setEditingMeal(null);
          }}
        />
      )}
    </div>
  );
}

function MealForm({ meal, onClose }: { meal: Meal | null; onClose: () => void }) {
  const [name, setName] = useState(meal?.name ?? '');
  const [price, setPrice] = useState(meal ? String(meal.price) : '');
  const [imageUrl, setImageUrl] = useState(meal?.image_url ?? '');
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');

  async function handleSave() {
    setError('');
    if (!name.trim() || !price.trim()) {
      setError('يرجى إدخال الاسم والسعر');
      return;
    }

    const priceNum = parseFloat(price);
    if (isNaN(priceNum) || priceNum < 0) {
      setError('السعر غير صالح');
      return;
    }

    setSaving(true);

    if (meal) {
      const { error: updateError } = await supabase
        .from('meals')
        .update({ name: name.trim(), price: priceNum, image_url: imageUrl.trim() || null })
        .eq('id', meal.id);
      setSaving(false);
      if (updateError) {
        setError('تعذر حفظ التعديلات');
        return;
      }
    } else {
      const { error: insertError } = await supabase.from('meals').insert({
        name: name.trim(),
        price: priceNum,
        image_url: imageUrl.trim() || null,
      });
      setSaving(false);
      if (insertError) {
        setError('تعذر إضافة الوجبة');
        return;
      }
    }

    onClose();
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/40" onClick={onClose}>
      <div className="bg-white rounded-4xl p-6 max-w-md w-full animate-fade-in" onClick={(e) => e.stopPropagation()}>
        <div className="flex items-center justify-between mb-5">
          <h3 className="text-lg font-bold text-secondary-900">{meal ? 'تعديل الوجبة' : 'إضافة وجبة جديدة'}</h3>
          <button onClick={onClose} className="text-neutral-400 hover:text-secondary-700 transition">
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-secondary-700 mb-1.5">اسم الوجبة</label>
            <input
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="w-full rounded-2xl border border-neutral-200 bg-neutral-50 px-4 py-2.5 text-secondary-900 focus:outline-none focus:ring-2 focus:ring-primary-500 transition"
              placeholder="بيتزا، برغر، شاورما..."
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-secondary-700 mb-1.5">السعر (ل.س)</label>
            <input
              type="number"
              value={price}
              onChange={(e) => setPrice(e.target.value)}
              className="w-full rounded-2xl border border-neutral-200 bg-neutral-50 px-4 py-2.5 text-secondary-900 focus:outline-none focus:ring-2 focus:ring-primary-500 transition"
              placeholder="25000"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-secondary-700 mb-1.5">رابط الصورة</label>
            <input
              type="url"
              value={imageUrl}
              onChange={(e) => setImageUrl(e.target.value)}
              className="w-full rounded-2xl border border-neutral-200 bg-neutral-50 px-4 py-2.5 text-secondary-900 focus:outline-none focus:ring-2 focus:ring-primary-500 transition"
              placeholder="https://..."
            />
          </div>

          {error && (
            <p className="text-error-600 text-sm bg-error-50 border border-error-200 rounded-xl px-3 py-2 text-center">
              {error}
            </p>
          )}

          <button
            onClick={handleSave}
            disabled={saving}
            className="w-full bg-primary-600 hover:bg-primary-700 disabled:opacity-60 text-white font-bold rounded-2xl py-3 transition flex items-center justify-center gap-2"
          >
            {saving && <Loader2 className="w-5 h-5 animate-spin" />}
            {meal ? 'حفظ التعديلات' : 'إضافة الوجبة'}
          </button>
        </div>
      </div>
    </div>
  );
}
