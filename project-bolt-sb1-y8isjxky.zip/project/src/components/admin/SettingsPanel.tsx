import { useEffect, useState } from 'react';
import { Check, Loader2, Lock, Phone, Settings, User } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { useAppSettings } from '@/hooks/useAppSettings';
import type { AdminProfile } from '@/types';

export default function SettingsPanel() {
  const { settings } = useAppSettings();
  const [appName, setAppName] = useState('');
  const [logoUrl, setLogoUrl] = useState('');
  const [adminUsername, setAdminUsername] = useState('');
  const [adminPhone, setAdminPhone] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [savingIdentity, setSavingIdentity] = useState(false);
  const [savingSecurity, setSavingSecurity] = useState(false);
  const [identitySaved, setIdentitySaved] = useState(false);
  const [securitySaved, setSecuritySaved] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    setAppName(settings.app_name);
    setLogoUrl(settings.logo_url ?? '');
  }, [settings]);

  useEffect(() => {
    async function loadProfile() {
      const { data } = await supabase
        .from('admin_profile')
        .select('username, phone')
        .eq('id', 1)
        .maybeSingle();
      if (data) {
        setAdminUsername(data.username);
        setAdminPhone(data.phone);
      }
    }
    loadProfile();
  }, []);

  async function handleSaveIdentity() {
    setSavingIdentity(true);
    setError('');
    await supabase
      .from('app_settings')
      .update({ app_name: appName.trim() || 'توصيل', logo_url: logoUrl.trim() || null, updated_at: new Date().toISOString() })
      .eq('id', 1);
    setSavingIdentity(false);
    setIdentitySaved(true);
    setTimeout(() => setIdentitySaved(false), 2500);
  }

  async function handleSaveSecurity() {
    setSavingSecurity(true);
    setError('');

    await supabase
      .from('admin_profile')
      .update({ username: adminUsername.trim(), phone: adminPhone.trim(), updated_at: new Date().toISOString() })
      .eq('id', 1);

    if (newPassword) {
      const { error: pwdError } = await supabase.auth.updateUser({ password: newPassword });
      if (pwdError) {
        setError('تعذر تحديث كلمة المرور: ' + pwdError.message);
        setSavingSecurity(false);
        return;
      }
      setNewPassword('');
    }

    setSavingSecurity(false);
    setSecuritySaved(true);
    setTimeout(() => setSecuritySaved(false), 2500);
  }

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-xl font-bold text-secondary-900 mb-4 flex items-center gap-2">
          <Settings className="w-5 h-5 text-primary-600" />
          إعدادات الهوية
        </h2>
        <div className="bg-white rounded-3xl p-5 shadow-card space-y-4">
          <div>
            <label className="block text-sm font-medium text-secondary-700 mb-1.5">اسم التطبيق</label>
            <input
              type="text"
              value={appName}
              onChange={(e) => setAppName(e.target.value)}
              className="w-full rounded-2xl border border-neutral-200 bg-neutral-50 px-4 py-2.5 text-secondary-900 focus:outline-none focus:ring-2 focus:ring-primary-500 transition"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-secondary-700 mb-1.5">رابط شعار التطبيق</label>
            <input
              type="url"
              value={logoUrl}
              onChange={(e) => setLogoUrl(e.target.value)}
              className="w-full rounded-2xl border border-neutral-200 bg-neutral-50 px-4 py-2.5 text-secondary-900 focus:outline-none focus:ring-2 focus:ring-primary-500 transition"
              placeholder="https://..."
            />
          </div>
          <button
            onClick={handleSaveIdentity}
            disabled={savingIdentity}
            className="bg-primary-600 hover:bg-primary-700 disabled:opacity-60 text-white font-bold rounded-2xl py-3 px-6 transition flex items-center gap-2"
          >
            {savingIdentity ? <Loader2 className="w-5 h-5 animate-spin" /> : identitySaved ? <Check className="w-5 h-5" /> : null}
            {identitySaved ? 'تم الحفظ' : 'حفظ التغييرات'}
          </button>
        </div>
      </div>

      <div>
        <h2 className="text-xl font-bold text-secondary-900 mb-4 flex items-center gap-2">
          <Lock className="w-5 h-5 text-primary-600" />
          الأمان وبيانات الأدمن
        </h2>
        <div className="bg-white rounded-3xl p-5 shadow-card space-y-4">
          <div>
            <label className="block text-sm font-medium text-secondary-700 mb-1.5">اسم مستخدم الأدمن</label>
            <div className="relative">
              <User className="absolute right-3.5 top-1/2 -translate-y-1/2 w-5 h-5 text-neutral-400" />
              <input
                type="text"
                value={adminUsername}
                onChange={(e) => setAdminUsername(e.target.value)}
                className="w-full rounded-2xl border border-neutral-200 bg-neutral-50 pr-11 pl-4 py-2.5 text-secondary-900 focus:outline-none focus:ring-2 focus:ring-primary-500 transition"
              />
            </div>
          </div>
          <div>
            <label className="block text-sm font-medium text-secondary-700 mb-1.5">رقم هاتف الأدمن</label>
            <div className="relative">
              <Phone className="absolute right-3.5 top-1/2 -translate-y-1/2 w-5 h-5 text-neutral-400" />
              <input
                type="tel"
                value={adminPhone}
                onChange={(e) => setAdminPhone(e.target.value)}
                className="w-full rounded-2xl border border-neutral-200 bg-neutral-50 pr-11 pl-4 py-2.5 text-secondary-900 focus:outline-none focus:ring-2 focus:ring-primary-500 transition"
              />
            </div>
          </div>
          <div>
            <label className="block text-sm font-medium text-secondary-700 mb-1.5">كلمة مرور جديدة (اختياري)</label>
            <div className="relative">
              <Lock className="absolute right-3.5 top-1/2 -translate-y-1/2 w-5 h-5 text-neutral-400" />
              <input
                type="password"
                value={newPassword}
                onChange={(e) => setNewPassword(e.target.value)}
                className="w-full rounded-2xl border border-neutral-200 bg-neutral-50 pr-11 pl-4 py-2.5 text-secondary-900 focus:outline-none focus:ring-2 focus:ring-primary-500 transition"
                placeholder="اتركها فارغة لعدم التغيير"
              />
            </div>
          </div>

          {error && (
            <p className="text-error-600 text-sm bg-error-50 border border-error-200 rounded-xl px-3 py-2 text-center">
              {error}
            </p>
          )}

          <button
            onClick={handleSaveSecurity}
            disabled={savingSecurity}
            className="bg-primary-600 hover:bg-primary-700 disabled:opacity-60 text-white font-bold rounded-2xl py-3 px-6 transition flex items-center gap-2"
          >
            {savingSecurity ? <Loader2 className="w-5 h-5 animate-spin" /> : securitySaved ? <Check className="w-5 h-5" /> : null}
            {securitySaved ? 'تم الحفظ' : 'حفظ البيانات'}
          </button>
        </div>
      </div>
    </div>
  );
}
