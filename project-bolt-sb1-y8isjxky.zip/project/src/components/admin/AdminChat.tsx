import { useEffect, useRef, useState } from 'react';
import { ArrowRight, Loader2, MessageCircle, Send, X } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { useChatRooms } from '@/hooks/useChatRooms';
import { useChatMessages } from '@/hooks/useChatMessages';
import type { ChatRoom } from '@/types';

export default function AdminChat() {
  const { rooms, loading } = useChatRooms();
  const [activeRoom, setActiveRoom] = useState<ChatRoom | null>(null);

  if (activeRoom) {
    return <AdminChatRoom room={activeRoom} onBack={() => setActiveRoom(null)} />;
  }

  if (loading) {
    return (
      <div className="flex justify-center py-12">
        <Loader2 className="w-6 h-6 animate-spin text-primary-600" />
      </div>
    );
  }

  if (rooms.length === 0) {
    return (
      <div className="text-center py-12 text-neutral-400">
        <MessageCircle className="w-10 h-10 mx-auto mb-2 opacity-50" />
        <p>لا توجد محادثات بعد</p>
      </div>
    );
  }

  return (
    <div className="space-y-3">
      <h2 className="text-xl font-bold text-secondary-900">المحادثات المباشرة</h2>
      {rooms.map((room) => (
        <button
          key={room.id}
          onClick={() => setActiveRoom(room)}
          className="w-full bg-white rounded-3xl p-4 shadow-card hover:shadow-card-hover transition text-right flex items-center gap-3"
        >
          <div className="w-12 h-12 rounded-full bg-primary-100 text-primary-600 flex items-center justify-center font-bold text-lg flex-shrink-0">
            {room.customer_phone.slice(-2)}
          </div>
          <div className="flex-1 min-w-0">
            <h3 className="font-bold text-secondary-900">{room.customer_phone}</h3>
            <p className="text-xs text-neutral-400">
              {new Date(room.last_message_at).toLocaleString('ar', { dateStyle: 'short', timeStyle: 'short' })}
            </p>
          </div>
          <MessageCircle className="w-5 h-5 text-neutral-300" />
        </button>
      ))}
    </div>
  );
}

function AdminChatRoom({ room, onBack }: { room: ChatRoom; onBack: () => void }) {
  const { messages, loading, bottomRef } = useChatMessages(room.id);
  const [text, setText] = useState('');
  const [sending, setSending] = useState(false);
  const [previewImage, setPreviewImage] = useState<string | null>(null);

  async function handleSend() {
    if (!text.trim() || sending) return;

    setSending(true);

    const { error } = await supabase.from('chat_messages').insert({
      room_id: room.id,
      sender: 'admin',
      body: text.trim(),
    });

    setSending(false);

    if (error) {
      alert('تعذر إرسال الرسالة');
      return;
    }

    await supabase
      .from('chat_rooms')
      .update({ last_message_at: new Date().toISOString() })
      .eq('id', room.id);

    setText('');
  }

  return (
    <div className="flex flex-col h-[calc(100vh-8rem)]">
      <header className="bg-primary-600 text-white px-4 py-3 flex items-center gap-3 rounded-t-3xl flex-shrink-0">
        <button onClick={onBack} className="p-1 hover:bg-primary-700 rounded-xl transition">
          <ArrowRight className="w-6 h-6" />
        </button>
        <div className="flex-1">
          <h1 className="font-bold">{room.customer_phone}</h1>
        </div>
      </header>

      <div className="flex-1 overflow-y-auto bg-neutral-50 px-4 py-4 space-y-3">
        {loading && messages.length === 0 ? (
          <div className="flex justify-center pt-8">
            <Loader2 className="w-6 h-6 animate-spin text-primary-400" />
          </div>
        ) : (
          <>
            {messages.map((msg) => (
              <div
                key={msg.id}
                className={`flex ${msg.sender === 'admin' ? 'justify-start' : 'justify-end'}`}
              >
                <div
                  className={`max-w-[75%] rounded-3xl px-4 py-2.5 ${
                    msg.sender === 'admin'
                      ? 'bg-primary-600 text-white rounded-bl-lg'
                      : 'bg-white text-secondary-900 rounded-br-lg shadow-sm'
                  }`}
                >
                  {msg.image_url && (
                    <button onClick={() => setPreviewImage(msg.image_url)} className="block mb-1">
                      <img
                        src={msg.image_url}
                        alt="مرفق"
                        className="rounded-2xl max-w-full max-h-48 object-cover cursor-pointer hover:opacity-90 transition"
                      />
                    </button>
                  )}
                  {msg.body && <p className="text-sm leading-relaxed">{msg.body}</p>}
                  <p className={`text-[10px] mt-1 ${msg.sender === 'admin' ? 'text-primary-100' : 'text-neutral-400'}`}>
                    {new Date(msg.created_at).toLocaleTimeString('ar', { hour: '2-digit', minute: '2-digit' })}
                  </p>
                </div>
              </div>
            ))}
            <div ref={bottomRef} />
          </>
        )}
      </div>

      <div className="bg-white border-t border-neutral-200 px-3 py-3 flex items-center gap-2 rounded-b-3xl flex-shrink-0">
        <input
          type="text"
          value={text}
          onChange={(e) => setText(e.target.value)}
          onKeyDown={(e) => e.key === 'Enter' && handleSend()}
          placeholder="اكتب ردك..."
          className="flex-1 rounded-2xl bg-neutral-100 px-4 py-2.5 text-secondary-900 focus:outline-none focus:ring-2 focus:ring-primary-500 transition"
        />
        <button
          onClick={handleSend}
          disabled={sending || !text.trim()}
          className="w-10 h-10 rounded-2xl bg-primary-600 hover:bg-primary-700 disabled:opacity-50 text-white flex items-center justify-center transition flex-shrink-0"
        >
          {sending ? <Loader2 className="w-5 h-5 animate-spin" /> : <Send className="w-5 h-5" />}
        </button>
      </div>

      {previewImage && (
        <div
          className="fixed inset-0 z-50 bg-black/80 flex items-center justify-center p-4"
          onClick={() => setPreviewImage(null)}
        >
          <button className="absolute top-4 right-4 w-10 h-10 rounded-full bg-white/20 text-white flex items-center justify-center">
            <X className="w-6 h-6" />
          </button>
          <img
            src={previewImage}
            alt="معاينة"
            className="max-w-full max-h-full rounded-3xl object-contain"
            onClick={(e) => e.stopPropagation()}
          />
        </div>
      )}
    </div>
  );
}
