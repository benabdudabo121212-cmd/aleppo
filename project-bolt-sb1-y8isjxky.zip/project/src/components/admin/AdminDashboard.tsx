import { useState } from 'react';
import { ClipboardList, LogOut, MessageCircle, Settings, UtensilsCrossed } from 'lucide-react';
import MealManagement from './MealManagement';
import OrdersPanel from './OrdersPanel';
import AdminChat from './AdminChat';
import SettingsPanel from './SettingsPanel';
import { useAppSettings } from '@/hooks/useAppSettings';
import { useOrders } from '@/hooks/useOrders';

type Tab = 'orders' | 'meals' | 'chat' | 'settings';

interface AdminDashboardProps {
  onSignOut: () => void;
}

export default function AdminDashboard({ onSignOut }: AdminDashboardProps) {
  const [tab, setTab] = useState<Tab>('orders');
  const { settings } = useAppSettings();
  const { orders } = useOrders();
  const pendingCount = orders.filter((o) => o.status === 'pending').length;

  const tabs: { id: Tab; label: string; icon: typeof UtensilsCrossed; badge?: number }[] = [
    { id: 'orders', label: 'الطلبات', icon: ClipboardList, badge: pendingCount },
    { id: 'meals', label: 'الوجبات', icon: UtensilsCrossed },
    { id: 'chat', label: 'المحادثات', icon: MessageCircle },
    { id: 'settings', label: 'الإعدادات', icon: Settings },
  ];

  return (
    <div className="min-h-screen bg-neutral-50 flex flex-col">
      <header className="bg-primary-600 text-white shadow-card sticky top-0 z-30">
        <div className="max-w-5xl mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-11 h-11 rounded-2xl bg-white/20 flex items-center justify-center overflow-hidden">
              {settings.logo_url ? (
                <img src={settings.logo_url} alt={settings.app_name} className="w-full h-full object-cover" />
              ) : (
                <UtensilsCrossed className="w-6 h-6" />
              )}
            </div>
            <div>
              <h1 className="font-bold text-lg leading-tight">{settings.app_name}</h1>
              <p className="text-xs text-primary-100">لوحة تحكم الأدمن</p>
            </div>
          </div>
          <button
            onClick={onSignOut}
            className="text-sm bg-white/15 hover:bg-white/25 rounded-2xl px-3 py-2 transition flex items-center gap-1.5"
          >
            <LogOut className="w-4 h-4" />
            خروج
          </button>
        </div>
      </header>

      <nav className="bg-white border-b border-neutral-200 sticky top-[72px] z-20">
        <div className="max-w-5xl mx-auto px-2 flex">
          {tabs.map((t) => {
            const Icon = t.icon;
            const active = tab === t.id;
            return (
              <button
                key={t.id}
                onClick={() => setTab(t.id)}
                className={`flex-1 flex items-center justify-center gap-1.5 py-3.5 text-sm font-bold transition relative ${
                  active ? 'text-primary-600' : 'text-neutral-400 hover:text-secondary-600'
                }`}
              >
                <Icon className="w-5 h-5" />
                <span className="hidden sm:inline">{t.label}</span>
                {t.badge != null && t.badge > 0 && (
                  <span className="absolute top-2 left-1/2 -translate-x-6 sm:translate-x-4 bg-error-500 text-white text-[10px] font-bold rounded-full min-w-5 h-5 px-1 flex items-center justify-center">
                    {t.badge}
                  </span>
                )}
                {active && <span className="absolute bottom-0 left-0 right-0 h-0.5 bg-primary-600 rounded-t-full" />}
              </button>
            );
          })}
        </div>
      </nav>

      <main className="flex-1 max-w-5xl w-full mx-auto px-4 py-6">
        {tab === 'orders' && <OrdersPanel />}
        {tab === 'meals' && <MealManagement />}
        {tab === 'chat' && <AdminChat />}
        {tab === 'settings' && <SettingsPanel />}
      </main>
    </div>
  );
}
