import { useState } from 'react';
import { Minus, Plus, MapPin, Loader2, X, ShoppingBag, MessageCircle } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import type { Meal } from '@/types';

interface OrderModalProps {
  meal: Meal;
  onClose: () => void;
  onOpenChat: () => void;
}

export default function OrderModal({ meal, onClose, onOpenChat }: OrderModalProps) {
  const [quantity, setQuantity] = useState(1);
  const [phone, setPhone] = useState('');
  const [locating, setLocating] = useState(false);
  const [coords, setCoords] = useState<{ lat: number; lng: number } | null>(null);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState(false);

  const totalPrice = meal.price * quantity;

  function handleLocate() {
    setLocating(true);
    setError('');
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        setCoords({ lat: pos.coords.latitude, lng: pos.coords.longitude });
        setLocating(false);
      },
      () => {
        setError('تعذر تحديد موقعك. تأكد من تفعيل خدمة الموقع (GPS).');
        setLocating(false);
      },
      { enableHighAccuracy: true, timeout: 10000 }
    );
  }

  async function handleSubmit() {
    setError('');

    if (!phone.trim()) {
      setError('يرجى إدخال رقم الهاتف');
      return;
    }

    setSubmitting(true);

    const { error: insertError } = await supabase.from('orders').insert({
      meal_id: meal.id,
      meal_name: meal.name,
      meal_price: meal.price,
      quantity,
      phone: phone.trim(),
      latitude: coords?.lat ?? null,
      longitude: coords?.lng ?? null,
      status: 'pending',
    });

    setSubmitting(false);

    if (insertError) {
      setError('تعذر إرسال الطلب. حاول مرة أخرى.');
      return;
    }

    setSuccess(true);
  }

  if (success) {
    return (
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/40">
        <div className="bg-white rounded-4xl p-8 max-w-sm w-full text-center animate-fade-in">
          <div className="w-16 h-16 rounded-full bg-success-100 flex items-center justify-center mx-auto mb-4">
            <ShoppingBag className="w-8 h-8 text-success-600" />
          </div>
          <h3 className="text-xl font-bold text-secondary-900 mb-2">تم إرسال طلبك!</h3>
          <p className="text-neutral-500 mb-6">سيتم التواصل معك على رقم {phone} قريباً</p>
          <div className="flex gap-3">
            <button
              onClick={onClose}
              className="flex-1 bg-primary-600 hover:bg-primary-700 text-white font-bold rounded-2xl py-3 transition"
            >
              إغلاق
            </button>
            <button
              onClick={() => {
                onClose();
                onOpenChat();
              }}
              className="flex-1 bg-neutral-100 hover:bg-neutral-200 text-secondary-700 font-bold rounded-2xl py-3 transition flex items-center justify-center gap-2"
            >
              <MessageCircle className="w-5 h-5" />
              تتبع الطلب
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4 bg-black/40" onClick={onClose}>
      <div
        className="bg-white rounded-t-4xl sm:rounded-4xl w-full max-w-md max-h-[90vh] overflow-y-auto animate-fade-in"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="relative">
          {meal.image_url ? (
            <img src={meal.image_url} alt={meal.name} className="w-full h-48 object-cover rounded-t-4xl" />
          ) : (
            <div className="w-full h-48 bg-primary-100 rounded-t-4xl flex items-center justify-center">
              <ShoppingBag className="w-12 h-12 text-primary-300" />
            </div>
          )}
          <button
            onClick={onClose}
            className="absolute top-3 left-3 w-9 h-9 rounded-full bg-black/40 hover:bg-black/60 text-white flex items-center justify-center transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6 space-y-5">
          <div>
            <h3 className="text-xl font-bold text-secondary-900">{meal.name}</h3>
            <p className="text-primary-600 font-bold text-lg mt-1">
              {Number(meal.price).toLocaleString('ar')} ل.س
            </p>
          </div>

          <div>
            <label className="block text-sm font-medium text-secondary-700 mb-2">الكمية</label>
            <div className="flex items-center gap-3">
              <button
                onClick={() => setQuantity((q) => Math.max(1, q - 1))}
                className="w-10 h-10 rounded-2xl bg-neutral-100 hover:bg-neutral-200 text-secondary-700 flex items-center justify-center transition"
              >
                <Minus className="w-5 h-5" />
              </button>
              <span className="text-xl font-bold w-10 text-center">{quantity}</span>
              <button
                onClick={() => setQuantity((q) => q + 1)}
                className="w-10 h-10 rounded-2xl bg-primary-100 hover:bg-primary-200 text-primary-700 flex items-center justify-center transition"
              >
                <Plus className="w-5 h-5" />
              </button>
              <div className="flex-1 text-left">
                <span className="text-neutral-400 text-sm">الإجمالي: </span>
                <span className="font-bold text-primary-600">{totalPrice.toLocaleString('ar')} ل.س</span>
              </div>
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-secondary-700 mb-1.5">رقم الهاتف</label>
            <input
              type="tel"
              value={phone}
              onChange={(e) => setPhone(e.target.value)}
              className="w-full rounded-2xl border border-neutral-200 bg-neutral-50 px-4 py-3 text-secondary-900 focus:outline-none focus:ring-2 focus:ring-primary-500 focus:border-primary-500 transition"
              placeholder="09xxxxxxxx"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-secondary-700 mb-1.5">موقعك (GPS)</label>
            <button
              onClick={handleLocate}
              disabled={locating}
              className="w-full rounded-2xl border border-neutral-200 bg-neutral-50 hover:bg-primary-50 hover:border-primary-300 disabled:opacity-60 px-4 py-3 text-secondary-700 transition flex items-center justify-center gap-2"
            >
              {locating ? (
                <Loader2 className="w-5 h-5 animate-spin" />
              ) : (
                <MapPin className="w-5 h-5 text-primary-600" />
              )}
              {coords ? 'تم تحديد موقعك' : 'تحديد موقعي تلقائياً'}
            </button>
            {coords && (
              <p className="text-xs text-neutral-400 mt-1.5 text-center">
                {coords.lat.toFixed(4)}, {coords.lng.toFixed(4)}
              </p>
            )}
          </div>

          {error && (
            <p className="text-error-600 text-sm bg-error-50 border border-error-200 rounded-xl px-3 py-2 text-center">
              {error}
            </p>
          )}

          <button
            onClick={handleSubmit}
            disabled={submitting}
            className="w-full bg-success-500 hover:bg-success-600 disabled:opacity-60 text-white font-bold rounded-2xl py-3.5 transition shadow-card flex items-center justify-center gap-2"
          >
            {submitting ? <Loader2 className="w-5 h-5 animate-spin" /> : <ShoppingBag className="w-5 h-5" />}
            تأكيد وإرسال الطلب
          </button>
        </div>
      </div>
    </div>
  );
}
