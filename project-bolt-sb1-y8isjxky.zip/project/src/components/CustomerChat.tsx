import { useEffect, useRef, useState } from 'react';
import { ArrowRight, Image as ImageIcon, Loader2, Send, X } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { useChatMessages } from '@/hooks/useChatMessages';
import type { ChatRoom } from '@/types';

interface CustomerChatProps {
  phone: string;
  onBack: () => void;
}

export default function CustomerChat({ phone, onBack }: CustomerChatProps) {
  const [roomId, setRoomId] = useState<string | null>(null);
  const [initLoading, setInitLoading] = useState(true);
  const [text, setText] = useState('');
  const [pendingImage, setPendingImage] = useState<string | null>(null);
  const [uploading, setUploading] = useState(false);
  const [sending, setSending] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const { messages, loading, bottomRef } = useChatMessages(roomId);

  useEffect(() => {
    let active = true;

    async function initRoom() {
      const { data: existing } = await supabase
        .from('chat_rooms')
        .select('id')
        .eq('customer_phone', phone)
        .maybeSingle();

      if (existing && active) {
        setRoomId(existing.id);
        setInitLoading(false);
        return;
      }

      const { data: created, error } = await supabase
        .from('chat_rooms')
        .insert({ customer_phone: phone })
        .select('id')
        .single();

      if (active && !error && created) {
        setRoomId(created.id);
      }
      if (active) setInitLoading(false);
    }

    initRoom();

    return () => {
      active = false;
    };
  }, [phone]);

  async function handlePickImage() {
    fileInputRef.current?.click();
  }

  async function handleFileChange(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file || !roomId) return;

    setUploading(true);
    const ext = file.name.split('.').pop() || 'jpg';
    const fileName = `${roomId}/${Date.now()}.${ext}`;

    const { error: uploadError } = await supabase.storage
      .from('chat-images')
      .upload(fileName, file, { contentType: file.type });

    setUploading(false);

    if (uploadError) {
      alert('تعذر رفع الصورة. حاول مرة أخرى.');
      return;
    }

    const { data: urlData } = supabase.storage.from('chat-images').getPublicUrl(fileName);
    setPendingImage(urlData.publicUrl);

    e.target.value = '';
  }

  async function handleSend() {
    if (!roomId || !text.trim() && !pendingImage) return;
    if (sending) return;

    setSending(true);

    const { error } = await supabase.from('chat_messages').insert({
      room_id: roomId,
      sender: 'customer',
      body: text.trim() || null,
      image_url: pendingImage,
    });

    setSending(false);

    if (error) {
      alert('تعذر إرسال الرسالة. حاول مرة أخرى.');
      return;
    }

    await supabase
      .from('chat_rooms')
      .update({ last_message_at: new Date().toISOString() })
      .eq('id', roomId);

    setText('');
    setPendingImage(null);
  }

  if (initLoading) {
    return (
      <div className="flex items-center justify-center h-screen bg-neutral-50">
        <Loader2 className="w-8 h-8 animate-spin text-primary-600" />
      </div>
    );
  }

  return (
    <div className="flex flex-col h-screen bg-neutral-50">
      <header className="bg-primary-600 text-white px-4 py-4 flex items-center gap-3 shadow-card">
        <button onClick={onBack} className="p-1 hover:bg-primary-700 rounded-xl transition">
          <ArrowRight className="w-6 h-6" />
        </button>
        <div className="flex-1">
          <h1 className="font-bold">الدعم والمحادثة</h1>
          <p className="text-xs text-primary-100">{phone}</p>
        </div>
      </header>

      <div className="flex-1 overflow-y-auto px-4 py-4 space-y-3">
        {loading && messages.length === 0 ? (
          <div className="flex justify-center pt-8">
            <Loader2 className="w-6 h-6 animate-spin text-primary-400" />
          </div>
        ) : (
          <>
            {messages.length === 0 && (
              <div className="text-center text-neutral-400 pt-8">
                <p>أرسل شكواك أو استفساراتك هنا</p>
                <p className="text-sm mt-1">يمكنك إرفاق صورة للطلب</p>
              </div>
            )}
            {messages.map((msg) => (
              <div
                key={msg.id}
                className={`flex ${msg.sender === 'customer' ? 'justify-start' : 'justify-end'}`}
              >
                <div
                  className={`max-w-[75%] rounded-3xl px-4 py-2.5 ${
                    msg.sender === 'customer'
                      ? 'bg-white text-secondary-900 rounded-bl-lg shadow-sm'
                      : 'bg-primary-600 text-white rounded-br-lg'
                  }`}
                >
                  {msg.image_url && (
                    <img
                      src={msg.image_url}
                      alt="مرفق"
                      className="rounded-2xl mb-1 max-w-full max-h-48 object-cover"
                    />
                  )}
                  {msg.body && <p className="text-sm leading-relaxed">{msg.body}</p>}
                  <p className={`text-[10px] mt-1 ${msg.sender === 'customer' ? 'text-neutral-400' : 'text-primary-100'}`}>
                    {new Date(msg.created_at).toLocaleTimeString('ar', { hour: '2-digit', minute: '2-digit' })}
                  </p>
                </div>
              </div>
            ))}
            <div ref={bottomRef} />
          </>
        )}
      </div>

      {pendingImage && (
        <div className="px-4 pb-2">
          <div className="relative inline-block">
            <img src={pendingImage} alt="معاينة" className="w-20 h-20 object-cover rounded-2xl" />
            <button
              onClick={() => setPendingImage(null)}
              className="absolute -top-2 -left-2 w-6 h-6 rounded-full bg-error-500 text-white flex items-center justify-center"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}

      <div className="bg-white border-t border-neutral-200 px-3 py-3 flex items-center gap-2">
        <input
          ref={fileInputRef}
          type="file"
          accept="image/*"
          onChange={handleFileChange}
          className="hidden"
        />
        <button
          onClick={handlePickImage}
          disabled={uploading || !roomId}
          className="w-10 h-10 rounded-2xl bg-neutral-100 hover:bg-primary-100 text-neutral-600 hover:text-primary-600 flex items-center justify-center transition flex-shrink-0 disabled:opacity-50"
        >
          {uploading ? <Loader2 className="w-5 h-5 animate-spin" /> : <ImageIcon className="w-5 h-5" />}
        </button>
        <input
          type="text"
          value={text}
          onChange={(e) => setText(e.target.value)}
          onKeyDown={(e) => e.key === 'Enter' && handleSend()}
          placeholder="اكتب رسالتك..."
          className="flex-1 rounded-2xl bg-neutral-100 px-4 py-2.5 text-secondary-900 focus:outline-none focus:ring-2 focus:ring-primary-500 transition"
        />
        <button
          onClick={handleSend}
          disabled={sending || (!text.trim() && !pendingImage)}
          className="w-10 h-10 rounded-2xl bg-primary-600 hover:bg-primary-700 disabled:opacity-50 text-white flex items-center justify-center transition flex-shrink-0"
        >
          {sending ? <Loader2 className="w-5 h-5 animate-spin" /> : <Send className="w-5 h-5" />}
        </button>
      </div>
    </div>
  );
}
