import { useState, FormEvent } from 'react';
import { UtensilsCrossed, Eye, EyeOff, Loader2, Lock, Mail, Phone, User } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import type { AppSettings } from '@/types';

interface LoginScreenProps {
  settings: AppSettings;
  onEnterAsCustomer: () => void;
}

export default function LoginScreen({ settings, onEnterAsCustomer }: LoginScreenProps) {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [phone, setPhone] = useState('');
  const [email, setEmail] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [googleLoading, setGoogleLoading] = useState(false);
  const [error, setError] = useState('');

  async function handleSubmit(e: FormEvent) {
    e.preventDefault();
    setError('');

    if (!username.trim() || !password || !phone.trim() || !email.trim()) {
      setError('يرجى تعبئة جميع الحقول');
      return;
    }

    setSubmitting(true);

    try {
      const { data, error: signInError } = await supabase.auth.signInWithPassword({
        email: email.trim(),
        password,
      });

      if (signInError || !data.session) {
        onEnterAsCustomer();
        return;
      }

      const { data: profile } = await supabase
        .from('admin_profile')
        .select('username, phone')
        .eq('id', 1)
        .maybeSingle();

      const isAdminMatch =
        profile && profile.username === username.trim() && profile.phone === phone.trim();

      if (!isAdminMatch) {
        await supabase.auth.signOut();
        onEnterAsCustomer();
        return;
      }
      // Matching admin: session stays active, App.tsx routes to the dashboard.
    } catch {
      onEnterAsCustomer();
    } finally {
      setSubmitting(false);
    }
  }

  async function handleGoogleLogin() {
    setGoogleLoading(true);
    try {
      const { error: oauthError } = await supabase.auth.signInWithOAuth({
        provider: 'google',
        options: { redirectTo: window.location.origin },
      });
      if (oauthError) {
        setError('تعذر تشغيل تسجيل الدخول عبر جوجل. تأكد من تفعيل هذه الخدمة.');
        setGoogleLoading(false);
      }
    } catch {
      setError('تعذر تشغيل تسجيل الدخول عبر جوجل.');
      setGoogleLoading(false);
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-primary-50 via-white to-primary-100 flex items-center justify-center px-4 py-10">
      <div className="w-full max-w-md">
        <div className="flex flex-col items-center mb-8 animate-fade-in">
          <div className="w-20 h-20 rounded-4xl bg-primary-600 shadow-card-hover flex items-center justify-center mb-4 overflow-hidden">
            {settings.logo_url ? (
              <img src={settings.logo_url} alt={settings.app_name} className="w-full h-full object-cover" />
            ) : (
              <UtensilsCrossed className="w-10 h-10 text-white" strokeWidth={2.2} />
            )}
          </div>
          <h1 className="text-3xl font-extrabold text-secondary-900">{settings.app_name}</h1>
          <p className="text-neutral-500 mt-1">وجبتك المفضلة في الطريق إليك</p>
        </div>

        <form
          onSubmit={handleSubmit}
          className="bg-white rounded-4xl shadow-card p-7 space-y-4 animate-fade-in"
        >
          <div>
            <label className="block text-sm font-medium text-secondary-700 mb-1.5">اسم المستخدم</label>
            <div className="relative">
              <User className="absolute right-3.5 top-1/2 -translate-y-1/2 w-5 h-5 text-neutral-400" />
              <input
                type="text"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                className="w-full rounded-2xl border border-neutral-200 bg-neutral-50 pr-11 pl-4 py-3 text-secondary-900 focus:outline-none focus:ring-2 focus:ring-primary-500 focus:border-primary-500 transition"
                placeholder="اسم المستخدم"
                autoComplete="username"
              />
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-secondary-700 mb-1.5">كلمة المرور</label>
            <div className="relative">
              <Lock className="absolute right-3.5 top-1/2 -translate-y-1/2 w-5 h-5 text-neutral-400" />
              <input
                type={showPassword ? 'text' : 'password'}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full rounded-2xl border border-neutral-200 bg-neutral-50 pr-11 pl-11 py-3 text-secondary-900 focus:outline-none focus:ring-2 focus:ring-primary-500 focus:border-primary-500 transition"
                placeholder="كلمة المرور"
                autoComplete="current-password"
              />
              <button
                type="button"
                onClick={() => setShowPassword((v) => !v)}
                className="absolute left-3.5 top-1/2 -translate-y-1/2 text-neutral-400 hover:text-secondary-600 transition"
                aria-label="إظهار كلمة المرور"
              >
                {showPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
              </button>
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-secondary-700 mb-1.5">رقم الهاتف</label>
            <div className="relative">
              <Phone className="absolute right-3.5 top-1/2 -translate-y-1/2 w-5 h-5 text-neutral-400" />
              <input
                type="tel"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                className="w-full rounded-2xl border border-neutral-200 bg-neutral-50 pr-11 pl-4 py-3 text-secondary-900 focus:outline-none focus:ring-2 focus:ring-primary-500 focus:border-primary-500 transition"
                placeholder="09xxxxxxxx"
                autoComplete="tel"
              />
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-secondary-700 mb-1.5">البريد الإلكتروني</label>
            <div className="relative">
              <Mail className="absolute right-3.5 top-1/2 -translate-y-1/2 w-5 h-5 text-neutral-400" />
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full rounded-2xl border border-neutral-200 bg-neutral-50 pr-11 pl-4 py-3 text-secondary-900 focus:outline-none focus:ring-2 focus:ring-primary-500 focus:border-primary-500 transition"
                placeholder="example@email.com"
                autoComplete="email"
              />
            </div>
          </div>

          {error && (
            <p className="text-error-600 text-sm bg-error-50 border border-error-200 rounded-xl px-3 py-2 text-center">
              {error}
            </p>
          )}

          <button
            type="submit"
            disabled={submitting}
            className="w-full bg-primary-600 hover:bg-primary-700 disabled:opacity-60 text-white font-bold rounded-2xl py-3.5 transition shadow-card flex items-center justify-center gap-2"
          >
            {submitting && <Loader2 className="w-5 h-5 animate-spin" />}
            تسجيل الدخول
          </button>

          <div className="flex items-center gap-3 pt-1">
            <div className="flex-1 h-px bg-neutral-200" />
            <span className="text-xs text-neutral-400">أو</span>
            <div className="flex-1 h-px bg-neutral-200" />
          </div>

          <button
            type="button"
            onClick={handleGoogleLogin}
            disabled={googleLoading}
            className="w-full bg-white hover:bg-neutral-50 disabled:opacity-60 text-secondary-700 font-semibold rounded-2xl py-3 border border-neutral-200 transition flex items-center justify-center gap-2"
          >
            {googleLoading ? (
              <Loader2 className="w-5 h-5 animate-spin" />
            ) : (
              <GoogleIcon className="w-5 h-5" />
            )}
            المتابعة باستخدام حساب جوجل
          </button>
        </form>

        <button
          onClick={onEnterAsCustomer}
          className="w-full text-center text-neutral-500 hover:text-primary-600 font-medium mt-5 transition"
        >
          الدخول كزبون بدون تسجيل →
        </button>
      </div>
    </div>
  );
}

function GoogleIcon({ className }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 24 24">
      <path
        fill="#4285F4"
        d="M23.49 12.27c0-.79-.07-1.54-.19-2.27H12v4.51h6.47c-.29 1.48-1.14 2.73-2.44 3.58v2.98h3.94c2.3-2.12 3.62-5.24 3.62-8.8z"
      />
      <path
        fill="#34A853"
        d="M12 24c3.24 0 5.95-1.08 7.93-2.93l-3.94-2.98c-1.08.72-2.45 1.15-3.99 1.15-3.07 0-5.67-2.06-6.6-4.85H1.35v3.06C3.32 21.3 7.28 24 12 24z"
      />
      <path
        fill="#FBBC05"
        d="M5.4 14.39c-.24-.72-.38-1.48-.38-2.27s.14-1.55.38-2.27V6.79H1.35A11.97 11.97 0 000 12.12c0 1.93.46 3.75 1.35 5.33l4.05-3.06z"
      />
      <path
        fill="#EA4335"
        d="M12 4.75c1.76 0 3.34.6 4.58 1.79l3.5-3.5C17.94 1.19 15.24 0 12 0 7.28 0 3.32 2.7 1.35 6.79l4.05 3.06c.93-2.79 3.53-4.85 6.6-5.1z"
      />
    </svg>
  );
}
