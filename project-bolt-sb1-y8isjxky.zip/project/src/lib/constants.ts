export const ADMIN_EMAIL = 'benmuhammeddabo121212@gmail.com';
