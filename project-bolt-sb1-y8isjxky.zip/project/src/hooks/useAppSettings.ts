import { useEffect, useState } from 'react';
import { supabase } from '@/lib/supabase';
import type { AppSettings } from '@/types';

const DEFAULT_SETTINGS: AppSettings = { id: 1, app_name: 'توصيل', logo_url: null };

export function useAppSettings() {
  const [settings, setSettings] = useState<AppSettings>(DEFAULT_SETTINGS);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let active = true;

    async function load() {
      const { data, error } = await supabase
        .from('app_settings')
        .select('id, app_name, logo_url')
        .eq('id', 1)
        .maybeSingle();

      if (active && !error && data) {
        setSettings(data);
      }
      if (active) setLoading(false);
    }

    load();

    const channel = supabase
      .channel('app_settings_changes')
      .on(
        'postgres_changes',
        { event: '*', schema: 'public', table: 'app_settings' },
        (payload) => {
          if (payload.new) setSettings(payload.new as AppSettings);
        }
      )
      .subscribe();

    return () => {
      active = false;
      supabase.removeChannel(channel);
    };
  }, []);

  return { settings, loading };
}
