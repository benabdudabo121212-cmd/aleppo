import { useEffect, useState } from 'react';
import { supabase } from '@/lib/supabase';
import type { ChatRoom } from '@/types';

export function useChatRooms() {
  const [rooms, setRooms] = useState<ChatRoom[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let active = true;

    async function load() {
      const { data, error } = await supabase
        .from('chat_rooms')
        .select('id, customer_phone, customer_name, last_message_at, created_at')
        .order('last_message_at', { ascending: false });

      if (active && !error && data) setRooms(data);
      if (active) setLoading(false);
    }

    load();

    const channel = supabase
      .channel('chat_rooms_changes')
      .on(
        'postgres_changes',
        { event: '*', schema: 'public', table: 'chat_rooms' },
        () => load()
      )
      .subscribe();

    return () => {
      active = false;
      supabase.removeChannel(channel);
    };
  }, []);

  return { rooms, loading };
}
