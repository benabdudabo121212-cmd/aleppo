import { useEffect, useState } from 'react';
import { supabase } from '@/lib/supabase';
import type { Meal } from '@/types';

export function useMeals() {
  const [meals, setMeals] = useState<Meal[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let active = true;

    async function load() {
      const { data, error } = await supabase
        .from('meals')
        .select('id, name, price, image_url, created_at')
        .order('created_at', { ascending: false });

      if (active && !error && data) setMeals(data);
      if (active) setLoading(false);
    }

    load();

    const channel = supabase
      .channel('meals_changes')
      .on(
        'postgres_changes',
        { event: '*', schema: 'public', table: 'meals' },
        () => load()
      )
      .subscribe();

    return () => {
      active = false;
      supabase.removeChannel(channel);
    };
  }, []);

  return { meals, loading };
}
