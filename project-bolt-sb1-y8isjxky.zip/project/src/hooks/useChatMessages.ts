import { useEffect, useState, useRef } from 'react';
import { supabase } from '@/lib/supabase';
import type { ChatMessage } from '@/types';

export function useChatMessages(roomId: string | null) {
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [loading, setLoading] = useState(true);
  const bottomRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!roomId) {
      setMessages([]);
      setLoading(false);
      return;
    }

    let active = true;

    async function load() {
      if (!roomId) return;
      const { data, error } = await supabase
        .from('chat_messages')
        .select('id, room_id, sender, body, image_url, created_at')
        .eq('room_id', roomId)
        .order('created_at', { ascending: true });

      if (active && !error && data) setMessages(data);
      if (active) setLoading(false);
    }

    setLoading(true);
    load();

    const channel = supabase
      .channel(`chat_messages_${roomId}`)
      .on(
        'postgres_changes',
        { event: 'INSERT', schema: 'public', table: 'chat_messages', filter: `room_id=eq.${roomId}` },
        (payload) => {
          setMessages((prev) => {
            const msg = payload.new as ChatMessage;
            return prev.some((m) => m.id === msg.id) ? prev : [...prev, msg];
          });
        }
      )
      .subscribe();

    return () => {
      active = false;
      supabase.removeChannel(channel);
    };
  }, [roomId]);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  return { messages, loading, bottomRef };
}
