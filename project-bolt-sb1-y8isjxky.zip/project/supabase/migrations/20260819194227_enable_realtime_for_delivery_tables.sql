/*
# Enable realtime updates

Turns on live updates (Supabase Realtime) for `meals`, `orders`, and `app_settings`
so that:
- A new order appears instantly in the admin dashboard without refreshing.
- A meal or app-identity change made by the admin appears instantly on the
  customer menu without refreshing.

No security changes - realtime respects the same Row Level Security policies
already defined on these tables.
*/

DO $$
BEGIN
  BEGIN
    ALTER PUBLICATION supabase_realtime ADD TABLE meals;
  EXCEPTION WHEN duplicate_object THEN NULL;
  END;
  BEGIN
    ALTER PUBLICATION supabase_realtime ADD TABLE orders;
  EXCEPTION WHEN duplicate_object THEN NULL;
  END;
  BEGIN
    ALTER PUBLICATION supabase_realtime ADD TABLE app_settings;
  EXCEPTION WHEN duplicate_object THEN NULL;
  END;
END $$;
