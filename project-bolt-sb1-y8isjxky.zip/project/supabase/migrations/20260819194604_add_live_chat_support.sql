/*
# Live chat support (chat_rooms, chat_messages, image storage)

## Plain-English summary
Adds a real-time customer support chat so customers can send complaints/inquiries
to the restaurant admin, including photo attachments (e.g. a picture of a wrong
order). The admin sees incoming messages live and can reply from the dashboard.

## New Tables
1. `chat_rooms`
   - `id` (uuid, primary key)
   - `customer_phone` (text) - identifies the conversation (one room per phone number)
   - `customer_name` (text, nullable) - optional display name
   - `last_message_at` (timestamptz) - used for sorting rooms in the admin inbox
   - `created_at` (timestamptz)

2. `chat_messages`
   - `id` (uuid, primary key)
   - `room_id` (uuid, references chat_rooms, cascade delete)
   - `sender` (text) - 'customer' or 'admin'
   - `body` (text, nullable) - text content
   - `image_url` (text, nullable) - public URL of an uploaded image
   - `created_at` (timestamptz)

## Storage
- Creates a public bucket `chat-images` for complaint photos.
- Policy: anyone may upload (customers attach photos without an account);
  anyone may read (so both customer and admin can view the image).

## Security
- RLS enabled on both tables.
- `chat_rooms`: anyone may insert/select (customers create their own room by
  phone number); only authenticated (admin) may update/delete.
- `chat_messages`: anyone may insert (customers send messages); anyone may
  select (so both the anonymous customer and the signed-in admin can read the
  conversation). Only authenticated (admin) may delete.
- Realtime enabled on `chat_messages` and `chat_rooms` for live updates.
*/

CREATE TABLE IF NOT EXISTS chat_rooms (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  customer_phone text NOT NULL,
  customer_name text,
  last_message_at timestamptz DEFAULT now(),
  created_at timestamptz DEFAULT now(),
  UNIQUE (customer_phone)
);

CREATE TABLE IF NOT EXISTS chat_messages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  room_id uuid NOT NULL REFERENCES chat_rooms(id) ON DELETE CASCADE,
  sender text NOT NULL CHECK (sender IN ('customer','admin')),
  body text,
  image_url text,
  created_at timestamptz DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_chat_messages_room_created ON chat_messages (room_id, created_at ASC);
CREATE INDEX IF NOT EXISTS idx_chat_rooms_last_message ON chat_rooms (last_message_at DESC);

ALTER TABLE chat_rooms ENABLE ROW LEVEL SECURITY;
ALTER TABLE chat_messages ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "public_select_chat_rooms" ON chat_rooms;
CREATE POLICY "public_select_chat_rooms" ON chat_rooms FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "public_insert_chat_rooms" ON chat_rooms;
CREATE POLICY "public_insert_chat_rooms" ON chat_rooms FOR INSERT
  TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "admin_update_chat_rooms" ON chat_rooms;
CREATE POLICY "admin_update_chat_rooms" ON chat_rooms FOR UPDATE
  TO authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "admin_delete_chat_rooms" ON chat_rooms;
CREATE POLICY "admin_delete_chat_rooms" ON chat_rooms FOR DELETE
  TO authenticated USING (true);

DROP POLICY IF EXISTS "public_select_chat_messages" ON chat_messages;
CREATE POLICY "public_select_chat_messages" ON chat_messages FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "public_insert_chat_messages" ON chat_messages;
CREATE POLICY "public_insert_chat_messages" ON chat_messages FOR INSERT
  TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "admin_delete_chat_messages" ON chat_messages;
CREATE POLICY "admin_delete_chat_messages" ON chat_messages FOR DELETE
  TO authenticated USING (true);

DO $$
BEGIN
  BEGIN
    ALTER PUBLICATION supabase_realtime ADD TABLE chat_messages;
  EXCEPTION WHEN duplicate_object THEN NULL;
  END;
  BEGIN
    ALTER PUBLICATION supabase_realtime ADD TABLE chat_rooms;
  EXCEPTION WHEN duplicate_object THEN NULL;
  END;
END $$;

INSERT INTO storage.buckets (id, name, public)
VALUES ('chat-images', 'chat-images', true)
ON CONFLICT (id) DO NOTHING;

DROP POLICY IF EXISTS "public_upload_chat_images" ON storage.objects;
CREATE POLICY "public_upload_chat_images" ON storage.objects FOR INSERT
  TO anon, authenticated WITH CHECK (bucket_id = 'chat-images');

DROP POLICY IF EXISTS "public_read_chat_images" ON storage.objects;
CREATE POLICY "public_read_chat_images" ON storage.objects FOR SELECT
  TO anon, authenticated USING (bucket_id = 'chat-images');
