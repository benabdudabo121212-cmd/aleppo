/*
# Delivery app schema (meals, orders, app identity, admin profile)

## Plain-English summary
This sets up everything the restaurant delivery app needs to store data permanently:
- The list of meals the admin publishes for customers to order.
- Incoming customer orders (with a snapshot of the meal name/price at order time,
  the customer's phone number, and GPS coordinates).
- The app's public identity (app name + logo shown to everyone).
- The admin's private profile (username + phone used to verify admin login).

## New Tables
1. `app_settings` (singleton row)
   - `id` (integer, always 1) - guarantees only one settings row exists
   - `app_name` (text) - the public name of the app
   - `logo_url` (text) - the public logo/hero image url
   - `updated_at` (timestamptz)

2. `admin_profile` (singleton row, PRIVATE - never exposed to anonymous visitors)
   - `id` (integer, always 1)
   - `username` (text) - used to verify admin login attempts
   - `phone` (text) - used to verify admin login attempts
   - `updated_at` (timestamptz)

3. `meals`
   - `id` (uuid, primary key)
   - `name` (text)
   - `price` (numeric) - price in Syrian pounds
   - `image_url` (text)
   - `created_at` (timestamptz)

4. `orders`
   - `id` (uuid, primary key)
   - `meal_id` (uuid, references meals, nullable if meal later removed)
   - `meal_name` / `meal_price` (text/numeric) - snapshot copied automatically
     from the `meals` table at the moment of the order, so the price a customer
     is shown is always the real published price, never a value the customer's
     browser could tamper with.
   - `quantity` (integer, must be > 0)
   - `phone` (text) - customer's contact number
   - `latitude` / `longitude` (double precision) - GPS location, optional
   - `status` (text) - pending / accepted / preparing / on_the_way / completed / cancelled
   - `created_at` (timestamptz)

## Security
- Row Level Security is enabled on all four tables.
- `app_settings` and `meals` are readable by everyone (anon + authenticated) because
  customers browse the menu and see the app branding without signing in.
- `admin_profile` has NO anonymous access at all - only a signed-in session can read
  or update it. This is what makes the login screen's admin check safe: a visitor
  can only see the real admin username/phone after Supabase has already verified
  their password.
- Only signed-in ("authenticated") sessions can add/edit/delete meals, edit
  `app_settings`, or read/update orders. Since this app never lets customers create
  an account, the only account that can ever be signed in is the restaurant's admin
  account - so "authenticated" effectively means "admin" throughout this schema.
- Anyone (including anonymous customers) can INSERT an order, because placing an
  order does not require an account - but they cannot read or modify existing orders.
- A trigger (`set_order_meal_snapshot`) overwrites `meal_name`/`meal_price` on every
  order insert by looking up the real, current values from the `meals` table. This
  means the price stored for an order can never be forged by a customer's browser.
*/

CREATE TABLE IF NOT EXISTS app_settings (
  id integer PRIMARY KEY DEFAULT 1 CHECK (id = 1),
  app_name text NOT NULL DEFAULT 'توصيل',
  logo_url text,
  updated_at timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS admin_profile (
  id integer PRIMARY KEY DEFAULT 1 CHECK (id = 1),
  username text NOT NULL,
  phone text NOT NULL,
  updated_at timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS meals (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  price numeric(10,2) NOT NULL CHECK (price >= 0),
  image_url text,
  created_at timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS orders (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  meal_id uuid REFERENCES meals(id) ON DELETE SET NULL,
  meal_name text NOT NULL,
  meal_price numeric(10,2) NOT NULL,
  quantity integer NOT NULL DEFAULT 1 CHECK (quantity > 0),
  phone text NOT NULL,
  latitude double precision,
  longitude double precision,
  status text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','accepted','preparing','on_the_way','completed','cancelled')),
  created_at timestamptz DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_orders_created_at ON orders (created_at DESC);

ALTER TABLE app_settings ENABLE ROW LEVEL SECURITY;
ALTER TABLE admin_profile ENABLE ROW LEVEL SECURITY;
ALTER TABLE meals ENABLE ROW LEVEL SECURITY;
ALTER TABLE orders ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "public_select_app_settings" ON app_settings;
CREATE POLICY "public_select_app_settings" ON app_settings FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "admin_update_app_settings" ON app_settings;
CREATE POLICY "admin_update_app_settings" ON app_settings FOR UPDATE
  TO authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "admin_select_admin_profile" ON admin_profile;
CREATE POLICY "admin_select_admin_profile" ON admin_profile FOR SELECT
  TO authenticated USING (true);

DROP POLICY IF EXISTS "admin_update_admin_profile" ON admin_profile;
CREATE POLICY "admin_update_admin_profile" ON admin_profile FOR UPDATE
  TO authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "public_select_meals" ON meals;
CREATE POLICY "public_select_meals" ON meals FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "admin_insert_meals" ON meals;
CREATE POLICY "admin_insert_meals" ON meals FOR INSERT
  TO authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "admin_update_meals" ON meals;
CREATE POLICY "admin_update_meals" ON meals FOR UPDATE
  TO authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "admin_delete_meals" ON meals;
CREATE POLICY "admin_delete_meals" ON meals FOR DELETE
  TO authenticated USING (true);

DROP POLICY IF EXISTS "public_insert_orders" ON orders;
CREATE POLICY "public_insert_orders" ON orders FOR INSERT
  TO anon, authenticated WITH CHECK (quantity > 0 AND phone <> '');

DROP POLICY IF EXISTS "admin_select_orders" ON orders;
CREATE POLICY "admin_select_orders" ON orders FOR SELECT
  TO authenticated USING (true);

DROP POLICY IF EXISTS "admin_update_orders" ON orders;
CREATE POLICY "admin_update_orders" ON orders FOR UPDATE
  TO authenticated USING (true) WITH CHECK (true);

CREATE OR REPLACE FUNCTION set_order_meal_snapshot()
RETURNS trigger AS $$
BEGIN
  SELECT name, price INTO NEW.meal_name, NEW.meal_price
  FROM meals WHERE id = NEW.meal_id;

  IF NEW.meal_name IS NULL THEN
    RAISE EXCEPTION 'Invalid meal_id';
  END IF;

  RETURN NEW;
END;
$$ LANGUAGE plpgsql SET search_path = public, pg_temp;

DROP TRIGGER IF EXISTS trg_set_order_meal_snapshot ON orders;
CREATE TRIGGER trg_set_order_meal_snapshot
  BEFORE INSERT ON orders
  FOR EACH ROW EXECUTE FUNCTION set_order_meal_snapshot();

INSERT INTO app_settings (id, app_name, logo_url)
VALUES (1, 'توصيل', NULL)
ON CONFLICT (id) DO NOTHING;

INSERT INTO admin_profile (id, username, phone)
VALUES (1, 'MUHAMMED', '0938591126')
ON CONFLICT (id) DO NOTHING;
